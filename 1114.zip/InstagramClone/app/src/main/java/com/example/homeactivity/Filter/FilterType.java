package com.example.homeactivity.Filter;

public enum FilterType {
    NONE,
    STYLE1,
    STYLE2,
    STYLE3,
    STYLE4,
    STYLE5,
    STYLE6,
    STYLE7,
    STYLE8,
    STYLE9,
    STYLE10,
    STYLE11,
    STYLE12,
    STYLE13,
    STYLE14,
    STYLE15
}
